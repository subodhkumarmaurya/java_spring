package com.gregchance.firstrouting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstroutingApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstroutingApplication.class, args);
	}

}
