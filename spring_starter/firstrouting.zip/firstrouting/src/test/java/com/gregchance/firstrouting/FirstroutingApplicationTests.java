package com.gregchance.firstrouting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstroutingApplicationTests {

	@Test
	void contextLoads() {
	}

}
