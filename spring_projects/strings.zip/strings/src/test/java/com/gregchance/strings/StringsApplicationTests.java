package com.gregchance.strings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringsApplicationTests {

	@Test
	void contextLoads() {
	}

}
