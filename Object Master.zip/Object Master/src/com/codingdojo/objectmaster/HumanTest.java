package com.codingdojo.objectmaster;

public class HumanTest {

	public static void main(String[] args) {
		Human h1 = new Human();
		Human h2 = new Human();
		h1.attackHuman(h1);

	}

}
